data class User(
    val login: String,
    val name: String?,
    val public_repos: Int,
    val followers: Int,
    val following: Int,
    val created_at: String
)

data class Repo(
    val name: String,
    val description: String?,
    val language: String?,
    val created_at: String
)
