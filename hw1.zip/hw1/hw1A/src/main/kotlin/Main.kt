import kotlinx.coroutines.runBlocking

val userCache = mutableListOf<User>()
val repoCache = mutableMapOf<String, List<Repo>>()

fun main() = runBlocking {
    val api = GitHubApi.create()

    while (true) {
        try {
            println("\n========== MENU ==========")
            println("1. Search and fetch user from GitHub")
            println("2. Show all cached users")
            println("3. Search user from cache")
            println("4. Show all repos of a user (from cache)")
            println("5. Search specific repo of a user (from cache)")
            println("6. Exit")
            println("==========================")

            when (readLine()?.trim()) {
                "1" -> fetchUser(api)
                "2" -> showUsers()
                "3" -> searchUser()
                "4" -> searchUserRepo()
                "5" -> showRepo()
                "6" ->{
                    println("Existing")
                    return@runBlocking}
                else -> println("Invalid option.")
            }

        } catch (e: Exception) {
            println("⚠️ Unexpected error: ${e.message}")
        }
    }
}


suspend fun fetchUser(api: GitHubApi) {
    println("Enter GitHub username:")
    val username = readLine()!!

    val userResponse = api.getUser(username).body()
    val repoResponse = api.getRepos(username).body()

    if (userResponse != null) {
        println("User: ${userResponse.name}")
        if (userCache.none { it.login == userResponse.login }) {
            userCache.add(userResponse)
        } else {
            println("User already in cache.")
        }

        if (repoResponse != null) {
            repoCache[username] = repoResponse
        } else {
            println("Warning: Repositories could not be fetched for this user.")
        }
    } else {
        println("Error: Could not fetch user from GitHub.")
    }
}

fun showUsers() {
    if (userCache.isEmpty()) {
        println("No users in cache.")
    } else {
        println("Cached Users:")
        userCache.forEach {
            println("Username: ${it.login}, Name: ${it.name}")
        }
    }
}

fun searchUser() {
    println("Enter username to search in cache:")
    val username = readLine()!!
    val user = userCache.find { it.login.contains(username, ignoreCase = true) }

    if (user != null) {
        println("User found: ${user.name} (Username: ${user.login})")
    } else {
        println("No user found with the name $username.")
    }
}

fun searchUserRepo() {
    println("Enter username to view cached repositories:")
    val username = readLine()!!

    val repos = repoCache[username]
    if (repos != null && repos.isNotEmpty()) {
        println("Repositories for $username:")
        repos.forEach { repo ->
            println("Repo: ${repo.name}, Language: ${repo.language}, Created At: ${repo.created_at}")
        }
    } else {
        println("No repositories found in cache for user '$username'.")
    }
}

fun showRepo() {
    println("Enter GitHub username:")
    val username = readLine()?.trim() ?: run {
        println("Invalid username input.")
        return
    }

    println("Enter the repository name:")
    val repoName = readLine()?.trim() ?: run {
        println("Invalid repository name.")
        return
    }

    val repos = repoCache[username]
    if (repos == null) {
        println("Error: No repositories cached for user '$username'.")
        return
    }

    val repo = repos.find { it.name == repoName }

    if (repo != null) {
        println("Repository: ${repo.name}")
        println("Description: ${repo.description ?: "No description"}")
        println("Language: ${repo.language ?: "Unknown"}")
        println("Created At: ${repo.created_at}")
    } else {
        println("Error: Repository '$repoName' not found for user '$username' in cache.")
    }
}




